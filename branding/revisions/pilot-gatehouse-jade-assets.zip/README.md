# Gatehouse by Sun — jade and gold assets

Approved direction: lighter jade G2A guardian arch with a warm golden inner ring.
Tagline: Identity. Trust. Protection.

## Contents
- branding/assets/readme-banner.png — approved original banner, 2172 × 724 pixels, unchanged.
- branding/assets/symbol.png — transparent 1024 × 1024 canonical PNG symbol.
- branding/assets/icons/ — 16, 24, 32, 48, 64, 96, 128, 180, 192, 256, 512 and 1024 pixel PNGs.
- branding/assets/social-preview.png — 1280 × 640 social image.
- branding/assets/social-card.png — 1200 × 630 social image.
- branding/assets/refs/symbol-extraction-source.png — full-resolution transparent extraction source.
- PREVIEW.png — banner and symbol review on light/dark surfaces with icon size examples.
- manifest.json — file inventory, dimensions and SHA-256 checksums.

## Usage
Retain PNG transparency. Preserve aspect ratios, square icon canvases and padding. Do not recolor, redraw or independently regenerate icon sizes; derive future sizes from symbol.png. Small sizes retain the full artwork, with naturally reduced texture and ring detail. Social images fit the original banner without stretching or cropping, adding forest-green space above and below.

## Provenance
Banner: the approved Jade Gatehouse with Golden Arch artwork. The built-in image-generation tool isolated the emblem using that banner as reference; it can introduce small pixel-level differences. The symbol was then centered and resized deterministically. Every supplied icon is a direct Lanczos resize of the one canonical symbol.

Extraction prompt: Isolate the original jade sculpted G arch and golden light ring, preserving geometry, material, color and lighting; remove text, background, floor and reflections; use true transparency including the inner opening.

## Handoff
Assets are arranged under branding/assets/, with sources under refs/. This ZIP is an artwork handoff; it does not rename a product or repository. manifest.json is an inventory, not a claim of compatibility with a particular installer schema. Repository revision names (v1.zip, v2.zip, etc.) should be assigned by the installer after successful installation. No revision history or existing repository assets are bundled here.
